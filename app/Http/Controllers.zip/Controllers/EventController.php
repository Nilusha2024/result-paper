<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Models\ResultEvent;
use Illuminate\Support\Facades\DB;
use App\Models\ResultCompetitor;
use App\Models\ResultPool;
use Carbon\Carbon;

class EventController extends Controller
{
    /**
     * Display a listing of the events.
     *
     * @return \Illuminate\Http\Response
     */

     public function index(Request $request)
     {
         $fromDate = $request->input('fromDate');
         $toDate = $request->input('toDate');
     
         $query = ResultEvent::query();
     
         // Filter events based on date range if provided
         if ($fromDate && $toDate) {
             $fromDate = Carbon::parse($fromDate);
             $toDate = Carbon::parse($toDate)->endOfDay();
     
             $query->whereBetween('created_at', [$fromDate, $toDate]);
         }
     
         $events = $query->get();
     
         return view('events.index', compact('events', 'fromDate', 'toDate'));
     }
     
    public function show(ResultEvent $event)
    {
        $event->load('competitors', 'dividends', 'pools', 'competitors.prices');
        return view('events.show', compact('event'));
    }

    public function downloadAll(Request $request)
    {
        // Get the filter dates from the session
        $fromDate = session('fromDate');
        $toDate = session('toDate');
        // dd($request->session()->all());
        // Apply the date filter to the query
        $query = ResultEvent::with('competitors');

        if ($fromDate && $toDate) {
            $fromDate = Carbon::parse($fromDate);
            $toDate = Carbon::parse($toDate)->endOfDay();
        
            $query->whereBetween('created_at', [$fromDate, $toDate]);
        }

        // Get events based on the filter
        $events = $query->get();


        // Create an array to store file contents for each event
        $eventFiles = [];

        foreach ($events as $event) {
            $eventData = [
                'Event Name: ' => $event->event_name,
                'Description: ' => $event->description,
                'Race Type: ' => $event->event_type,
                'Start Date & Time: ' => $event->start_datetime,
                'End Date & Time: ' => $event->end_datetime,
                'Going: ' => $event->going,
                'Status: ' => $event->status,
                'Length: ' => $event->length,
                'Country Name: ' => $event->country_name,
                'Country Code: ' => $event->country_code,
                'Location Code: ' => $event->location_code,
                'Meeting ID: ' => $event->meeting_id,
            ];

            // Loop through competitors for this event
            $competitorData = [];
            foreach ($event->competitors as $competitor) {
                $competitorInfo = [
                    'Name: ' => $competitor->name,
                    'Description: ' => $competitor->description,
                    'Competitor No: ' => $competitor->competitor_no,
                    'Post No: ' => $competitor->post_no,
                    'Finish Position: ' => $competitor->finish_position,
                    'Form: ' => $competitor->form,
                    'Weight: ' => $competitor->weight,
                    'Jockey: ' => $competitor->jockey,
                    'Trainer: ' => $competitor->trainer,
                    'Status: ' => $competitor->status,
                    'Fav Status: ' => $competitor->fav_status,
                ];

                $competitorData[] = $competitorInfo;
            }

            $eventData['Competitors'] = $competitorData;

            // Create a text representation of the event's data
            $eventTextData = "Event ID: " . $event->event_id . "\n";
            foreach ($eventData as $key => $value) {
                if (is_array($value)) {
                    foreach ($value as $competitorInfo) {
                        foreach ($competitorInfo as $infoKey => $infoValue) {
                            $eventTextData .= $infoKey . ' ' . $infoValue . "\n";
                        }
                    }
                } else {
                    $eventTextData .= $key . ' ' . $value . "\n";
                }
            }

            // Add the event's text data to the array with event_id as the key
            $eventFiles[$event->event_id . '.txt'] = $eventTextData;
        }

        // Set the content type and headers for a zip archive download
        $headers = [
            'Content-Type' => 'application/zip',
            'Content-Disposition' => 'attachment; filename=all_events.zip',
        ];

        // Create a zip archive containing individual text files
        $zip = new \ZipArchive;
        $zipFilename = storage_path('app/public/all_events.zip');

        if ($zip->open($zipFilename, \ZipArchive::CREATE)) {
            foreach ($eventFiles as $filename => $textData) {
                $zip->addFromString($filename, $textData);
            }
            $zip->close();
        }

        // Return the zip archive as a downloadable response
        return response()->download($zipFilename, 'all_events.zip')->deleteFileAfterSend(true);
    }


    public function download(Request $request)
    {
        // Get the selected from_date and to_date from the request
        $fromDate = $request->input('from_date');
        $toDate = $request->input('to_date');

        // Parse the date strings into Carbon instances
        $fromDate = Carbon::parse($fromDate);
        $toDate = Carbon::parse($toDate);

        // Fetch all ResultEvent data with competitors within the selected date range
        $events = ResultEvent::with(['competitors' => function ($query) {
            $query->orderBy('finish_position');
        }])->whereDate('start_datetime', '>=', $fromDate)
        ->whereDate('start_datetime', '<=', $toDate)
        ->get();

        $textData = '';
        $previousCourse = null; // Variable to track the previous course
        $currentCourse = null;
        $eventCount = 0;

        foreach ($events as $event) {

            $courseInfo = "@Course: " . $event->event_name;

            $event_type = $event->event_type;
            
            if ($event_type == 'R') {
                $courseInfo .= ' (THR)';
            } elseif ($event_type == 'H') {
                $courseInfo .= ' (HNS)';
            } elseif ($event_type == 'G') {
                $courseInfo .= ' (GRY)';
            }

            // Check if the course has changed, and add course info if it's a new course
            if ($previousCourse !== $courseInfo) {
                $textData .= $courseInfo . "\n\n";
                $previousCourse = $courseInfo;
            }

                // Check if the course has changed
            if ($currentCourse !== $courseInfo) {
                $currentCourse = $courseInfo;
                $eventCount = 0; // Reset the event count for the new course
            }

            // Increment the event count for the current course
            $eventCount++;

            // Get all related data for the event
            $eventData = [
                "@Race : <B>". $eventCount ."<B>",
            ];

            $horseNumber = 1;

            // Loop through competitors associated with the event
            $competitors = $event->competitors;

            foreach ($competitors as $competitor) {
                // Check if finish_position is not null before adding to $eventData
                if ($competitor->finish_position !== null) {
                    $dividendWin = null;
                    $dividendPlace = null;
            
                    // Retrieve the WIN dividend for the first horse
                    if ($horseNumber === 1) {
                        $dividendWin = $competitor->dividend()
                            ->where('dividend_type', 'WIN')
                            ->first();
                    }
            
                    // For the fourth horse, set PLC to "N/F/D"
                    if ($horseNumber === 4) {
                        // $horseInfo = "@Horse" . $horseNumber . " :\t" . $competitor->finish_position . "\t" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no . ")"."N/F/D";
                        $nameLength = strlen($competitor->name);
                            
                        if ($nameLength >= 1 && $nameLength <= 4) {
                            $horseInfo = "@Horse" . $horseNumber . " :\t" . $competitor->finish_position . "\t" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no . ")"."\t\t\t\t\tN/F/D";
                        } elseif ($nameLength >= 5 && $nameLength <= 12) {
                            $horseInfo = "@Horse" . $horseNumber . " :\t" . $competitor->finish_position . "\t" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no . ")"."\t\t\t\tN/F/D";
                        } elseif ($nameLength >= 13 && $nameLength <= 20) {
                            $horseInfo = "@Horse" . $horseNumber . " :\t" . $competitor->finish_position . "\t" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no . ")"."\t\t\tN/F/D";
                        } elseif ($nameLength >= 21 && $nameLength <= 29) {
                            $horseInfo = "@Horse" . $horseNumber . " :\t" . $competitor->finish_position . "\t" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no . ")"."\t\tN/F/D";
                        } elseif ($nameLength >= 29 && $nameLength <= 36) {
                            $horseInfo = "@Horse" . $horseNumber . " :\t" . $competitor->finish_position . "\t" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no . ")"."\t\tN/F/D";
                        }
                    } else {
                        // Retrieve the PLC dividend based on the finish position for all other horses
                        $dividendPlace = $competitor->dividend()
                            ->where('dividend_type', 'PLC')
                            ->where('instance', $competitor->finish_position)
                            ->first();
            
                        $horseInfo = "@Horse" . $horseNumber . " :	" . $competitor->finish_position;
            
                        // Add <B> tags for the first horse only
                        if ($horseNumber === 1) {
                            // $horseInfo .= "	<B>" . $competitor->name . "(" . $competitor->competitor_no . ")</B>";
                            $nameLength = strlen($competitor->name);

                            if ($nameLength >= 1 && $nameLength <= 5) {
                                $horseInfo .= "	<B>" . $competitor->name . "(" . $competitor->competitor_no . ")</B>\t\t\t";
                            } elseif ($nameLength >= 6 && $nameLength <= 13) {
                                $horseInfo .= "	<B>" . $competitor->name . "(" . $competitor->competitor_no . ")</B>\t\t";
                            } elseif ($nameLength >= 14 && $nameLength <= 21) {
                                $horseInfo .= "	<B>" . $competitor->name . "(" . $competitor->competitor_no . ")</B>\t";
                            }
                        } elseif ($horseNumber === 2) {
                            // $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")	" ;
                            $nameLength = strlen($competitor->name);
                            
                            if ($nameLength >= 1 && $nameLength <= 4) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t\t\t\t";
                            } elseif ($nameLength >= 5 && $nameLength <= 12) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t\t\t";
                            } elseif ($nameLength >= 13 && $nameLength <= 20) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t\t";
                            } elseif ($nameLength >= 21 && $nameLength <= 29) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t";
                            } elseif ($nameLength >= 29 && $nameLength <= 36) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t";
                            }
                        }elseif ($horseNumber === 3) {
                            // $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")	" ;
                            $nameLength = strlen($competitor->name);
                            
                            if ($nameLength >= 1 && $nameLength <= 4) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t\t\t\t";
                            } elseif ($nameLength >= 5 && $nameLength <= 12) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t\t\t";
                            } elseif ($nameLength >= 13 && $nameLength <= 20) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t\t";
                            } elseif ($nameLength >= 21 && $nameLength <= 29) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t";
                            } elseif ($nameLength >= 29 && $nameLength <= 36) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t";
                            }
                        }else{
                            // $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")	" ;
                            $nameLength = strlen($competitor->name);
                            
                            if ($nameLength >= 1 && $nameLength <= 4) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t\t\t\t";
                            } elseif ($nameLength >= 5 && $nameLength <= 12) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t\t\t";
                            } elseif ($nameLength >= 13 && $nameLength <= 20) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t\t";
                            } elseif ($nameLength >= 21 && $nameLength <= 29) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t";
                            } elseif ($nameLength >= 29 && $nameLength <= 36) {
                                $horseInfo .= "	" . ucwords(strtolower($competitor->name)) . "(" . $competitor->competitor_no. ")\t";
                            }
                        }
            
                        if ($dividendWin && $horseNumber === 1) {
                            $horseInfo .= "" . number_format($dividendWin->dividend_amount * 10, 2);
                        }                       
                        if ($dividendPlace) {
                            $horseInfo .= "	" . number_format($dividendPlace->dividend_amount * 10, 2);
                        }
                        else {
                            $nameLength = strlen($competitor->name);
                            
                            if ($nameLength >= 1 && $nameLength <= 4) {
                                $horseInfo .= "\t\t\t\tN/T/D";
                            } elseif ($nameLength >= 5 && $nameLength <= 12) {
                                $horseInfo .= "\tN/T/D";
                            } elseif ($nameLength >= 13 && $nameLength <= 20) {
                                $horseInfo .= "\tN/T/D";
                            } elseif ($nameLength >= 21 && $nameLength <= 29) {
                                $horseInfo .= "\tN/T/D";
                            } elseif ($nameLength >= 29 && $nameLength <= 36) {
                                $horseInfo .= "\tN/T/D";
                            }
                        }
                    }
            
                    $runnerNumber = $competitor->runner->runner_numbers;
            
                    $eventData[] = $horseInfo;
                    $horseNumber++;
                }
            }
            
            $notRunners = $competitors->where('status', 'NR')->pluck('name', 'competitor_no')->toArray();

            if (!empty($notRunners)) {
                // Convert "Not Runners" names to sentence case with competitor_no in brackets
                $notRunners = array_map(function($name, $competitor_no) {
                    return ucwords(strtolower($name)) . "($competitor_no)";
                }, $notRunners, array_keys($notRunners)); // Pass keys (competitor_no) as the second argument
                $notRunnersText = "@NotRunners: <B> Not Run: - <B>  " . implode(', ', $notRunners);
                $eventData[] = $notRunnersText;
            }

            $comments1 = "@Comments1:";
            $dividendTypes = ['QIN' => 'QU', 'EXA' => 'EX', 'TRF' => 'TF', 'FirstFour' => 'FF'];

            // Extract competitor numbers from the $competitors array
            $competitorNumbers = [];

            foreach ($competitors as $competitor) {
                // Check if finish_position is not null before adding to $competitorNumbers
                if ($competitor->finish_position !== null) {
                    $competitorNumbers[] = $competitor->competitor_no;
                }
            }

            foreach ($dividendTypes as $type => $outputType) {
                // Sort competitorNumbers if necessary based on finish position

                // Retrieve the dividend for the specific type
                $dividend = $competitors->first()->dividend()
                    ->where('dividend_type', $type)
                    ->first();

                $dividendAmount = $dividend ? number_format($dividend->dividend_amount * 10, 2) : '0.00';

                // Check the dividend type and the number of competitors
                if ($type === 'QIN' && count($competitorNumbers) >= 2) {
                    // Limit the EX dividend amount to $2,500.00 if it exceeds
                    $dividendAmount = min($dividendAmount, 2500);
                    // $comments1 .= " $outputType ({$competitorNumbers[0]}-{$competitorNumbers[1]}) $dividendAmount  ";
                    $comments1 .= " $outputType ({$competitorNumbers[0]}-{$competitorNumbers[1]}) " . $dividendAmount  ;
                } elseif ($type === 'EXA' && count($competitorNumbers) >= 2) {
                    $comments1 .= " $outputType ({$competitorNumbers[0]}-{$competitorNumbers[1]}) $dividendAmount  ";
                } elseif ($type === 'TRF' && count($competitorNumbers) >= 3) {
                    // Limit the TF dividend amount to $20,000.00 if it exceeds
                    $dividendAmount = min($dividendAmount, 20000);
                    // $comments1 .= " $outputType ({$competitorNumbers[0]}-{$competitorNumbers[1]}-{$competitorNumbers[2]}) $dividendAmount  ";
                    $comments1 .= " $outputType ({$competitorNumbers[0]}-{$competitorNumbers[1]}-{$competitorNumbers[2]}) " . $dividendAmount  ;
                } elseif ($type === 'FirstFour' && count($competitorNumbers) >= 4) {
                    $comments1 .= " $outputType ({$competitorNumbers[0]}-{$competitorNumbers[1]}-{$competitorNumbers[2]}-{$competitorNumbers[3]}) $dividendAmount  ";
                } else {
                    $comments1 .= " $outputType $dividendAmount";
                }
            }

            // Add the comments section to the eventData array
            $eventData[] = $comments1;          

            foreach ($competitors as $competitor) {
                // Check if finish_position is not null and the event_type is 'R' or 'H' before adding to $eventData
                if ($competitor->finish_position !== null && in_array($event->event_type, ['R', 'H'])) {
                    $dividendInstance = $competitor->dividend->instance;
            
                    $horseInfo = "@Trainer1 :";
            
                    if ($competitor->jockey !== null) {
                        $horseInfo .= " (" . $competitor->jockey;
                        if ($competitor->trainer !== null) {
                            $horseInfo .= ")  (" . $competitor->trainer . ")";
                        }
                    } elseif ($competitor->trainer !== null) {
                        $horseInfo .= " (" . $competitor->trainer . ")";
                    }
            
                    $eventData[] = $horseInfo;
                    break; // Break the loop after adding the trainer info for one competitor
                }
            }

            $eventData[] = "@ Line : ----------------------------------------------------";

            // Create a text representation of the data for this event
            foreach ($eventData as $value) {
                $textData .= $value . "\n";
            }
        }

        $today = now()->format('Y-m-d'); // Get today's date in the format 'YYYY-MM-DD'
        $filename = "events_$today.txt";
        $headers = [
            'Content-Type' => 'text/plain',
            'Content-Disposition' => "attachment; filename=$filename",
        ];

        // Return a response with the text data
        return response($textData, 200, $headers);
    }
}