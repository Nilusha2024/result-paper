<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Meeting;
use App\Models\ResultCompetitor;
use App\Models\ResultCompetitorPrice;
use App\Models\ResultDividend;
use App\Models\ResultEvent;
use App\Models\ResultMeeting;
use App\Models\ResultMeetingEvent;
use App\Models\ResultPool;
use DateTime;
use Exception;
use FilesystemIterator;
use GlobIterator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpParser\Node\Stmt\TryCatch;


class ResultPaperController extends Controller
{

    public function index()
    {
        // link page later
    }


    // Aussie result downloads
    // -----------------------

    public function storeAllAussieFeedData()
    {
        // set meeting data first
        $this->storeAllAussieResultMeetingData();
        // then event data
        $this->storeAllAussieResultEventData();
    }

    public function storeAllAussieResultMeetingData()
    {
        try {

            // truncate table data (TESTING USE ONLY)
            $this->flushAussieResultMeetingTables();

            // Start new transaction
            DB::beginTransaction();

            // local storage path :
            $directory = storage_path('app/xml/TabAussieXML/');

            // Setting up iterator to iterate through files
            $iterator = new GlobIterator($directory . '*.xml', FilesystemIterator::KEY_AS_FILENAME);

            // Find the XML tags with the results
            foreach ($iterator as $file) {

                $filename = $iterator->key();
                $xmlNode = simplexml_load_file(storage_path('app/xml/TabAussieXML/') . $filename);
                $arrayData = $this->xmlToArray($xmlNode);

                // meeting date filter's over here
                if (
                    isset($arrayData['meeting']) &&
                    isset($arrayData['meeting']['@date'])
                    // date('Y-m-d') === date('Y-m-d', strtotime($arrayData['meeting']['@date']))
                ) {

                    $meetingList = $arrayData['meeting'];

                    // if there's only a single one, wrap it
                    if ($meetingList['@location'] ?? false) {
                        $meetingList = [$meetingList];
                    }

                    foreach ($meetingList as $meeting) {

                        $createdMeeting = ResultMeeting::create([
                            'location' => $meeting['@location'] ?? null,
                            'date' => new DateTime($meeting['@date'] ?? null),
                            'name' => $meeting['@name'] ?? null,
                            'type' => $meeting['@type'] ?? null,
                            'going' => $meeting['@going'] ?? null,
                            'code' => $meeting['@code'] ?? null,
                            'weather' => $meeting['@weather'] ?? null,
                        ]);


                        // if events are set within the meeting tags
                        if (isset($arrayData['meeting']['event'])) {

                            foreach ($arrayData['meeting']['event'] as $event) {

                                ResultMeetingEvent::create([
                                    'meeting_id' => $createdMeeting->id ?? null,
                                    'runners' => $event['@runners'] ?? null,
                                    'distance' => $event['@distance'] ?? null,
                                    'name' => $event['@name'] ?? null,
                                    'number' => $event['@number'] ?? null,
                                    'start_time' => new DateTime($event['@starttime'] ?? null),
                                    'status' => $event['@status'] ?? null,
                                ]);
                            }
                        }
                    }
                }
            }

            // if the transaction concluded without any errors, commit em
            DB::commit();
            print_r('Meeting data stored.');
        } catch (Exception $e) {
            DB::rollback();
            dd($e);
        }
    }


    public function storeAllAussieResultEventData()
    {
        try {

            // truncate table data (TESTING USE ONLY)
            $this->flushAussieResultEventTables();

            // Start new transaction
            DB::beginTransaction();

            // local storage path :
            $directory = storage_path('app/xml/TabAussieXML/');

            // Setting up iterator to iterate through files
            $iterator = new GlobIterator($directory . '*.xml', FilesystemIterator::KEY_AS_FILENAME);

            // Find the XML tags with the results
            foreach ($iterator as $file) {

                $filename = $iterator->key();
                $xmlNode = simplexml_load_file(storage_path('app/xml/TabAussieXML/') . $filename);
                $arrayData = $this->xmlToArray($xmlNode);

                // event date filter's over here
                if (
                    isset($arrayData['category']) &&
                    isset($arrayData['category']['@date'])
                    // date('Y-m-d') === date('Y-m-d', strtotime($arrayData['category']['@date']))
                ) {

                    // if events are set & mtp is available (temporary fix)
                    if (isset($arrayData['category']['competition']['event']) && isset($arrayData['category']['competition']['event']['@mtp'])) {

                        // loading all event & competition data
                        $eventList = $arrayData['category']['competition']['event'];

                        // if there's only one event, wrap it
                        if ($eventList['@id'] ?? false) {
                            $eventList = [$eventList];
                        }

                        foreach ($eventList as $event) {

                            // grab the meeting record that matches for the event
                            $meetingForEvent = ResultMeeting::where('name', $event['@name'])->first();

                            ResultEvent::create([
                                'event_id' => $event['@id'] ?? null,
                                'meeting_id' => $meetingForEvent->id ?? null,
                                'event_name' => $event['@name'] ?? null,
                                'race_num' => $event['@racenum'] ?? null,
                                'event_type' => $meetingForEvent->type ?? null,
                                'description' => $event['@description'] ?? null,
                                'start_datetime' => new DateTime($event['@startdatetime'] ?? null),
                                'utc_start_datetime' => new DateTime($event['@utc_startdatetime'] ?? null),
                                'end_datetime' => new DateTime($event['@enddatetime'] ?? null),
                                'going' => $event['@going'] ?? null,
                                'status' => $event['@status'] ?? null,
                                'length' => $event['@length'] ?? null,
                                'country_name' => $event['@countryname'] ?? null,
                                'country_code' => $event['@countrycode'] ?? null,
                                'location_code' => $event['@locationcode'] ?? null,
                                'mtp' => $event['@mtp'] ?? null,
                                'closed_time' => new DateTime($event['@closedtime'] ?? null)
                            ]);


                            if (isset($event['market']['competitor'])) {
                                foreach ($event['market']['competitor'] as $competitor) {

                                    // Note : Greyhounds don't have jockeys, so their jockey field comes as ''.
                                    // Creating competitor tag records
                                    ResultCompetitor::create([
                                        'competitor_id' => $competitor['@id'] ?? null,
                                        'event_id' => $event['@id'] ?? null,
                                        'name' => $competitor['@name'] ?? null,
                                        'description' => $competitor['@description'] ?? null,
                                        'competitor_no' => $competitor['@number'] ?? null,
                                        'post_no' => $competitor['@postnumber'] ?? null,
                                        'finish_position' => $competitor['@finishposn'] ?? null,
                                        'form' => $competitor['@form'] ?? null,
                                        'weight' => $competitor['@weight'] ?? null,
                                        'jockey' => (isset($competitor['@jockey']) && $competitor['@jockey'] !== '') ? $competitor['@jockey'] : null,
                                        'trainer' => $competitor['@trainer'] ?? null,
                                        'status' => $competitor['@status'] ?? null,
                                        'fav_status' => $competitor['@favstatus'] ?? null,
                                    ]);

                                    if (isset($competitor['price'])) {
                                        foreach ($competitor['price'] as $price) {

                                            // Creating price tag records
                                            ResultCompetitorPrice::create([
                                                'competitor_id' => $competitor['@id'] ?? null,
                                                'price_type' => $price['@pricetype'] ?? null,
                                                'odds' => $price['@odds'] ?? null,
                                            ]);
                                        }
                                    }
                                }
                            }


                            // Process 'pool' ------------------------------------------------

                            if (isset($event['market'])) {
                                if (isset($event['market']['pool'])) {
                                    foreach ($event['market']['pool'] as $pool) {
                                        ResultPool::create([
                                            'event_id' => $event['@id'] ?? null,
                                            'pool_id' => $pool['@id'] ?? null,
                                            'pool_type' => $pool['@pooltype'] ?? null,
                                            'jackpot' => $pool['@jackpot'] ?? null,
                                            'leg_number' => $pool['@legnumber'] ?? null,
                                            'status' => $pool['@status'] ?? null,
                                            'pool_total' => $pool['@pooltotal'] ?? null,
                                            'substitute' => $pool['@substitude'] ?? null,
                                            'closed_time' => new DateTime($pool['@closedtime'] ?? null),
                                        ]);
                                    }
                                }
                            }

                            // Process 'result' and 'dividend' tags
                            if (isset($event['market']['result']['dividend'])) {

                                foreach ($event['market']['result']['dividend'] as $dividend) {

                                    ResultDividend::create([
                                        'event_id' => $event['@id'] ?? null,
                                        'dividend_type' => $dividend['@dividendtype'] ?? null,
                                        'instance' => $dividend['@instance'] ?? null,
                                        'dividend_amount' => $dividend['@dividendamount'] ?? null,
                                        'jackpot_carried_over' => $dividend['@jackpotcarriedover'] ?? null,
                                        'status' => $dividend['@status'] ?? null,
                                        'runner_numbers' => $dividend['@runnernumbers'] ?? null,
                                    ]);
                                }
                            }
                        }
                    }
                }
            }

            // if the transaction concluded without any errors, commit em
            DB::commit();
            print_r('Event data stored.');
        } catch (Exception $e) {
            DB::rollback();
            dd($e);
        }
    }

    // remove after development
    public function flushAussieResultEventTables()
    {
        try {

            ResultEvent::truncate();
            ResultCompetitor::truncate();
            ResultCompetitorPrice::truncate();
            ResultPool::truncate();
            ResultDividend::truncate();
        } catch (Exception $e) {
            dd($e);
        }
    }

    // remove after development
    public function flushAussieResultMeetingTables()
    {
        try {
            ResultMeeting::truncate();
            ResultMeetingEvent::truncate();
        } catch (Exception $e) {
            dd($e);
        }
    }



    public function download_event()
    {

        // DB::beginTransaction();

        try {

            // local storage path :
            $directory = storage_path('app/xml/TabAussieXML/');

            $iterator = new GlobIterator($directory . '*.xml', FilesystemIterator::KEY_AS_FILENAME);
            $n = 0;
            $response = array();

            if (count($iterator) == 0) {
                return array('status' => 1, 'msg' => 'Xml Folder Empty!');
                // array_push($response, 'No Matches');

                // return $response;
            }
            $iterator = new GlobIterator($directory . '*.xml', FilesystemIterator::KEY_AS_FILENAME);
            $n = 0;
            $response = array();

            if (count($iterator) == 0) {
                return array('status' => 1, 'msg' => 'Xml Folder Empty!');
                // array_push($response, 'No Matches');

                // return $response;
            } else {

                foreach ($iterator as $item) {

                    $inner_response = array();

                    $filename = $iterator->key();

                    // $xmlNode = simplexml_load_file('//172.16.50.39/Headend/TabAussieXML/meetingindex.xml');

                    $xmlNode = simplexml_load_file(storage_path('app/xml/TabAussieXML/meetingindex.xml'));

                    $arrayData = $this->xmlToArray($xmlNode);

                    $json = json_encode($arrayData);

                    // Get daily meeting data
                    $meetinglist = '';
                    if (isset($arrayData['meetings'])) {
                        if (isset($arrayData['meetings']['meeting'])) {
                            $meetinglist = $arrayData['meetings']['meeting'];

                            // Empty daily exist meeting
                            Meeting::query()->truncate();

                            // Enter Day Meeting
                            foreach ($meetinglist as $m) {

                                $code = '';
                                if (isset($m['@code'])) {
                                    $code = $m['@code'];
                                }

                                $data = Meeting::create([
                                    'location' => $m['@location'],
                                    'date' => $m['@date'],
                                    'name' => $m['@name'],
                                    'type' => $m['@type'],
                                    'code' => $code
                                ]);
                            }
                        }
                    }
                }

                // Empty daily exist meeting
                Event::query()->truncate();

                foreach ($iterator as $item) {

                    $inner_response = array();

                    // $iterator->key is the file names
                    $filename = $iterator->key();

                    $xmlNode = simplexml_load_file(storage_path('app/xml/TabAussieXML/') . $iterator->key());

                    $arrayData = $this->xmlToArray($xmlNode);

                    $json = json_encode($arrayData);

                    // Get daily meeting data
                    $eventlist = '';
                    if (isset($arrayData['meeting'])) {

                        if (isset($arrayData['meeting']['event'])) {
                            $eventlist = $arrayData['meeting']['event'];

                            // Enter Day Meeting
                            foreach ($eventlist as $ev) {
                                //Get Meeting_id
                                $meeting = Meeting::where('name', $arrayData['meeting']['@name'])->where('type', $arrayData['meeting']['@type'])->get();
                                $data = Event::create([
                                    'meeting_id' => $meeting[0]['id'],
                                    'name' => $ev['@name'],
                                    'event_number' => $ev['@number']

                                ]);
                            }
                        }
                    }
                }
            }

            // return json_encode($response);

            DB::commit();
            return array('status' => 1, 'msg' => 'Successfully Downloaded!');
        } catch (\Illuminate\Database\QueryException $e) {
            DB::rollback();
            return array('status' => 0, 'msg' => 'Unable to Download Event!');
        } catch (\Exception $e) {
            DB::rollback();
            return array('status' => 0, 'msg' => $e->getMessage());
        }
    }


    // XML to Array conversion
    // -----------------------

    public function xmlToArray($xml, $options = array())
    {
        if ($xml) {
            $defaults = array(
                'namespaceSeparator' => ':', //you may want this to be something other than a colon
                'attributePrefix' => '@',   //to distinguish between attributes and nodes with the same name
                'alwaysArray' => array(),   //array of xml tag names which should always become arrays
                'autoArray' => true,        //only create arrays for tags which appear more than once
                'textContent' => '$',       //key used for the text content of elements
                'autoText' => true,         //skip textContent key if node has no attributes or child nodes
                'keySearch' => false,       //optional search and replace on tag and attribute names
                'keyReplace' => false       //replace values for above search values (as passed to str_replace())
            );
            $options = array_merge($defaults, $options);
            $namespaces = $xml->getDocNamespaces();
            $namespaces[''] = null; //add base (empty) namespace

            //get attributes from all namespaces
            $attributesArray = array();
            foreach ($namespaces as $prefix => $namespace) {
                foreach ($xml->attributes($namespace) as $attributeName => $attribute) {
                    //replace characters in attribute name
                    if ($options['keySearch']) $attributeName =
                        str_replace($options['keySearch'], $options['keyReplace'], $attributeName);
                    $attributeKey = $options['attributePrefix']
                        . ($prefix ? $prefix . $options['namespaceSeparator'] : '')
                        . $attributeName;
                    $attributesArray[$attributeKey] = (string)$attribute;
                }
            }

            //get child nodes from all namespaces
            $tagsArray = array();
            foreach ($namespaces as $prefix => $namespace) {
                foreach ($xml->children($namespace) as $childXml) {
                    //recurse into child nodes
                    $childArray = $this->xmlToArray($childXml, $options);
                    // while(list($childTagName, $childProperties) = each($childArray)){
                    foreach ($childArray as $childTagName => $childProperties) {

                        //replace characters in tag name
                        if ($options['keySearch']) $childTagName =
                            str_replace($options['keySearch'], $options['keyReplace'], $childTagName);
                        //add namespace prefix, if any
                        if ($prefix) $childTagName = $prefix . $options['namespaceSeparator'] . $childTagName;

                        if (!isset($tagsArray[$childTagName])) {
                            //only entry with this key
                            //test if tags of this type should always be arrays, no matter the element count
                            $tagsArray[$childTagName] =
                                in_array($childTagName, $options['alwaysArray']) || !$options['autoArray']
                                ? array($childProperties) : $childProperties;
                        } elseif (
                            is_array($tagsArray[$childTagName]) && array_keys($tagsArray[$childTagName])
                            === range(0, count($tagsArray[$childTagName]) - 1)
                        ) {
                            //key already exists and is integer indexed array
                            $tagsArray[$childTagName][] = $childProperties;
                        } else {
                            //key exists so convert to integer indexed array with previous value in position 0
                            $tagsArray[$childTagName] = array($tagsArray[$childTagName], $childProperties);
                        }
                    }
                }
            }

            //get text content of node
            $textContentArray = array();
            $plainText = trim((string)$xml);
            if ($plainText !== '') $textContentArray[$options['textContent']] = $plainText;

            //stick it all together
            $propertiesArray = !$options['autoText'] || $attributesArray || $tagsArray || ($plainText === '')
                ? array_merge($attributesArray, $tagsArray, $textContentArray) : $plainText;

            //return node as array
            return array(
                $xml->getName() => $propertiesArray
            );
        }
    }
}
